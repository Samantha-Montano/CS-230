package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class GameService {

	private static List<Game> games = new ArrayList<Game>();

	private static long nextGameId = 1;

	/*
	 * The Singleton pattern makes sure only one instance of GameService
	 * exists in the application. The private constructor prevents other
	 * classes from creating new instances, while getInstance() gives
	 * access to the single shared instance.
	 */
	private static GameService instance = new GameService();

	private GameService() {
	}

	public static GameService getInstance() {
		return instance;
	}

	public Game addGame(String name) {

		Game game = null;

		/*
		 * The Iterator pattern lets the program to go through each game
		 * in the list one at a time. This is used to check for an existing
		 * game with the same name before creating a new one
		 */
		Iterator<Game> iterator = games.iterator();

		while (iterator.hasNext()) {
			Game currentGame = iterator.next();

			if (currentGame.getName().equals(name)) {
				game = currentGame;
				break;
			}
		}

		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		return game;
	}

	Game getGame(int index) {
		return games.get(index);
	}

	public Game getGame(long id) {

		Game game = null;

		Iterator<Game> iterator = games.iterator();

		while (iterator.hasNext()) {
			Game currentGame = iterator.next();

			if (currentGame.getId() == id) {
				game = currentGame;
				break;
			}
		}

		return game;
	}

	public Game getGame(String name) {

		Game game = null;

		Iterator<Game> iterator = games.iterator();

		while (iterator.hasNext()) {
			Game currentGame = iterator.next();

			if (currentGame.getName().equals(name)) {
				game = currentGame;
				break;
			}
		}

		return game;
	}

	public int getGameCount() {
		return games.size();
	}
}